import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class HistoryWindow {
    private JFrame frame;
    private JTable table;
    private JScrollPane scrollPane;
    private JButton clearButton;

    public HistoryWindow() {
        // Create the JFrame for the history window
        frame = new JFrame("Calculation History");
        frame.setSize(500, 350);  // Increased height for the button
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        // Create table with column names
        String[] columns = {"ID", "Expression", "Result", "Timestamp"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        scrollPane = new JScrollPane(table);

        // Create Clear History button
        clearButton = new JButton("Clear History");
        clearButton.addActionListener(e -> clearHistory(model));  // Action listener for clearing history

        // Set layout and add components
        frame.setLayout(new BorderLayout());
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(clearButton, BorderLayout.SOUTH);  // Position the button at the bottom of the frame

        // Fetch history from the database and populate the table
        SwingUtilities.invokeLater(() -> fetchHistory(model));

        // Make the frame visible
        frame.setVisible(true);
    }

    // Fetch history from the database and display it in the table
    private void fetchHistory(DefaultTableModel model) {
        String url = "jdbc:mysql://localhost:3306/CalculatorDB";
        String username = "root";
        String password = "";  // Adjust this based on your MySQL setup

        String query = "SELECT * FROM Calculations ORDER BY timestamp DESC";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            // Loop through the result set and populate the table
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String expression = resultSet.getString("expression");
                String result = resultSet.getString("result");
                Timestamp timestamp = resultSet.getTimestamp("timestamp");

                model.addRow(new Object[]{id, expression, result, timestamp});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to clear the history from the database
    private void clearHistory(DefaultTableModel model) {
        int confirm = JOptionPane.showConfirmDialog(frame, "Are you sure you want to clear the history?", "Clear History", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            String url = "jdbc:mysql://localhost:3306/CalculatorDB";
            String username = "root";
            String password = "";  // Adjust this based on your MySQL setup

            String query = "DELETE FROM Calculations";

            try (Connection connection = DriverManager.getConnection(url, username, password)) {
                PreparedStatement statement = connection.prepareStatement(query);
                statement.executeUpdate();

                // Clear the table model
                model.setRowCount(0);
                JOptionPane.showMessageDialog(frame, "History cleared successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Error clearing history: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        // Launch the history window
        SwingUtilities.invokeLater(HistoryWindow::new);
    }
}
