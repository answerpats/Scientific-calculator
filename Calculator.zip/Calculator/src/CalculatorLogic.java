import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class CalculatorLogic {
    private CalculatorDesign calculator;
    private Connection connection;

    public CalculatorLogic() {
        calculator = new CalculatorDesign();
        initializeDatabase();
        addEventListeners();
    }

    // Initializes the database connection
    private void initializeDatabase() {
        String url = "jdbc:mysql://localhost:3306/CalculatorDB";
        String username = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Database connected!");
        } catch (SQLException e) {
            System.out.println("Database connection failed: " + e.getMessage());
        }
    }

    // Event listeners for calculator buttons
    private void addEventListeners() {
        JButton[] buttons = calculator.getButtons();
        JTextField display = calculator.getDisplay();

        for (JButton button : buttons) {
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String command = e.getActionCommand();
                    switch (command) {
                        case "=":
                            try {
                                String expression = display.getText();
                                double result = evaluateExpression(expression);

                                // Display the result immediately
                                display.setText(String.valueOf(result));

                                // Log the calculation to the database
                                logCalculation(expression, result);

                            } catch (Exception ex) {
                                display.setText("Error");
                            }
                            break;
                        case "DEL":
                            if (!display.getText().isEmpty()) {
                                String currentText = display.getText();
                                display.setText(currentText.substring(0, currentText.length() - 1));
                            }
                            break;
                        case "CLEAR":
                            display.setText("");
                            break;
                        case "Hist":
                            new HistoryWindow();
                            break;
                        case "sin":
                        case "cos":
                        case "tan":
                        case "log":
                        case "√":
                            try {
                                double value = Double.parseDouble(display.getText());
                                double result = calculateAdvancedMath(command, value);
                                
                                // Display the result immediately
                                display.setText(String.valueOf(result));
                            } catch (Exception ex) {
                                display.setText("Error");
                            }
                            break;
                        default:
                            // For operators or numbers, append them to the display
                            display.setText(display.getText() + command);
                    }
                }
            });
        }
    }

    // Function to evaluate the expression
    private double evaluateExpression(String expression) {
        try {
            // Handle arithmetic expressions like addition, subtraction, etc.
            if (expression.contains("+")) {
                return evaluateAdditionSubtraction(expression, "\\+");
            } else if (expression.contains("-")) {
                return evaluateAdditionSubtraction(expression, "\\-");
            } else if (expression.contains("*")) {
                return evaluateMultiplicationDivision(expression, "\\*");
            } else if (expression.contains("/")) {
                return evaluateMultiplicationDivision(expression, "\\/");
            } else {
                return Double.parseDouble(expression); // For single number cases
            }
        } catch (Exception e) {
            System.out.println("Error evaluating expression: " + e.getMessage());
            return 0.0;
        }
    }

    // Evaluate addition and subtraction
    private double evaluateAdditionSubtraction(String expression, String operator) {
        String[] operands = expression.split(operator);
        double result = Double.parseDouble(operands[0]);

        for (int i = 1; i < operands.length; i++) {
            if (operator.equals("\\+")) {
                result += Double.parseDouble(operands[i]);
            } else if (operator.equals("\\-")) {
                result -= Double.parseDouble(operands[i]);
            }
        }

        return result;
    }

    // Evaluate multiplication and division
    private double evaluateMultiplicationDivision(String expression, String operator) {
        String[] operands = expression.split(operator);
        double result = Double.parseDouble(operands[0]);

        for (int i = 1; i < operands.length; i++) {
            if (operator.equals("\\*")) {
                result *= Double.parseDouble(operands[i]);
            } else if (operator.equals("\\/")) {
                result /= Double.parseDouble(operands[i]);
            }
        }

        return result;
    }

    // Calculate advanced math functions like sin, cos, tan, sqrt, log
    private double calculateAdvancedMath(String operation, double value) {
        switch (operation) {
            case "sin":
                return Math.sin(Math.toRadians(value)); // Sine of angle in degrees
            case "cos":
                return Math.cos(Math.toRadians(value)); // Cosine of angle in degrees
            case "tan":
                return Math.tan(Math.toRadians(value)); // Tangent of angle in degrees
            case "log":
                if (value > 0) {
                    return Math.log10(value); // Logarithm base 10
                } else {
                    return Double.NaN; // Logarithm undefined for non-positive values
                }
            case "√":
                if (value >= 0) {
                    return Math.sqrt(value); // Square root
                } else {
                    return Double.NaN; // Square root undefined for negative values
                }
            default:
                return 0;
        }
    }

    // Log the calculation to the database
    private void logCalculation(String expression, double result) {
        try {
            String query = "INSERT INTO Calculations (expression, result) VALUES (?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, expression);
            statement.setString(2, String.valueOf(result));
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }

    // Main method to run the calculator
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CalculatorLogic());
    }

    // InsertCalculation class (if needed, can be used for standalone inserts)
    public static class InsertCalculation {
        public static void main(String[] args) {
            String url = "jdbc:mysql://localhost:3306/CalculatorDB";
            String username = "root";
            String password = "";

            // SQL query to insert a calculation
            String expression = "5 + 3 * 2";
            String result = "11.0";

            try (Connection connection = DriverManager.getConnection(url, username, password)) {
                // SQL query to insert calculation data
                String query = "INSERT INTO Calculations (expression, result) VALUES (?, ?)";
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, expression);
                statement.setString(2, result);

                // Execute the query
                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("A calculation was inserted successfully!");
                }
            } catch (SQLException e) {
                System.out.println("Database connection failed: " + e.getMessage());
            }
        }
    }
}
