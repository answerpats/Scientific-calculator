import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorDesign extends JFrame {
    private JPanel displayPanel, buttonPanel;
    private JTextField display;
    private JButton[] buttons;

    // Button labels arranged neatly
    private String[] buttonLabels = {
        "7", "8", "9", "/", "DEL",
        "4", "5", "6", "*", "CLEAR",
        "1", "2", "3", "-", "(",
        "0", ".", "=", "+", ")",
        "sin", "cos", "tan", "√", "^",
        "log", "Hist"
    };

    public CalculatorDesign() {
        // Set frame properties
        setTitle("Scientific Calculator");
        setSize(450, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setResizable(false);

        // Display panel
        displayPanel = new JPanel();
        displayPanel.setLayout(new BorderLayout());
        displayPanel.setBackground(new Color(40, 44, 52)); // Dark background

        // Display field
        display = new JTextField();
        display.setFont(new Font("Arial", Font.BOLD, 30));
        display.setHorizontalAlignment(SwingConstants.RIGHT);
        display.setEditable(false);
        display.setBackground(new Color(60, 63, 65)); // Dark gray
        display.setForeground(Color.WHITE); // White text
        display.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        displayPanel.add(display, BorderLayout.CENTER);

        // Button panel
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(6, 5, 10, 10));
        buttonPanel.setBackground(new Color(40, 44, 52)); // Match display background

        // Buttons
        buttons = new JButton[buttonLabels.length];
        for (int i = 0; i < buttonLabels.length; i++) {
            buttons[i] = new RoundedButton(buttonLabels[i]);  // Use custom RoundedButton
            buttons[i].setFont(new Font("Arial", Font.BOLD, 18));
            buttons[i].setBackground(new Color(75, 110, 175)); // Blue shade
            buttons[i].setForeground(Color.WHITE); // White text
            buttons[i].setFocusPainted(false); // Remove focus border
            buttons[i].setBorder(BorderFactory.createLineBorder(new Color(50, 50, 50), 1)); // Subtle border
            buttonPanel.add(buttons[i]);
        }

        // Add components to frame
        add(displayPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);

        // Center the frame on screen
        setLocationRelativeTo(null);

        setVisible(true);
    }

    // Custom rounded button class
    class RoundedButton extends JButton {
        public RoundedButton(String label) {
            super(label);
        }

        @Override
        protected void paintComponent(Graphics g) {
            if (getModel().isPressed()) {
                g.setColor(getBackground().darker());
            } else if (getModel().isRollover()) {
                g.setColor(getBackground().brighter());
            } else {
                g.setColor(getBackground());
            }

            g.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);  // Rounded edges
            super.paintComponent(g);
        }

        @Override
        public void setBounds(int x, int y, int width, int height) {
            super.setBounds(x, y, width, height);
            setPreferredSize(new Dimension(60, 60));  // Adjust button size
        }
    }

    public JButton[] getButtons() {
        return buttons;
    }

    public JTextField getDisplay() {
        return display;
    }

    public static void main(String[] args) {
        new CalculatorDesign();
    }
}
